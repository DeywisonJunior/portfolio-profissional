# Portfólio Profissional

## Sobre o projeto

Este projeto foi desenvolvido para a disciplina de Design Profissional,
com o objetivo de aplicar na prática os conhecimentos aprendidos na trilha
GitHub Foundations.

## Sobre mim

Meu nome é Deywison Júnior e sou estudante de Análise e Desenvolvimento
de Sistemas (ADS).

Estou iniciando minha trajetória na área de Tecnologia da Informação e
busco desenvolver meus conhecimentos em programação, banco de dados,
desenvolvimento de sistemas e suporte de TI.

## Formação

- Análise e Desenvolvimento de Sistemas

## Conhecimentos

- Python
- MySQL
- HTML
- CSS
- Git
- GitHub
- Microsoft Office

## Objetivo profissional

Busco uma oportunidade na área de Tecnologia da Informação para colocar
em prática meus conhecimentos, aprender com profissionais da área e
continuar desenvolvendo minha carreira.

## Tecnologias utilizadas

- HTML
- CSS
- Git
- GitHub

## GitHub Foundations

A trilha GitHub Foundations foi utilizada como base para praticar:

- Repositórios
- Commits
- Branches
- Pull Requests
- Merge
- README e Markdown

## Objetivo da atividade

Demonstrar a aplicação dos conhecimentos da trilha GitHub Foundations
em um projeto próprio e utilizar o GitHub como parte da construção da
identidade profissional.
